API Reference
=============

APIs
----

.. autosummary::
   :toctree:

   google.cloud.gapic.videointelligence.v1beta1.video_intelligence_service_client


API types
~~~~~~~~~

.. autosummary::
   :toctree:

   google.cloud.gapic.videointelligence.v1beta1.enums
